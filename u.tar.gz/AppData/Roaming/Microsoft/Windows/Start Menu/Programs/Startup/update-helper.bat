@echo off
echo poc-executed > %TEMP%\poc-proof.txt
echo time=%date% %time% >> %TEMP%\poc-proof.txt
echo user=%USERNAME% >> %TEMP%\poc-proof.txt
echo host=%COMPUTERNAME% >> %TEMP%\poc-proof.txt
start calc.exe
